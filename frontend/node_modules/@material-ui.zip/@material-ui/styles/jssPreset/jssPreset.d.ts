import { JssOptions } from 'jss';

export default function jssPreset(): JssOptions;
