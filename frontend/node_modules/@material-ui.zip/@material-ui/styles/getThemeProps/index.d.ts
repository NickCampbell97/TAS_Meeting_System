export { default } from './getThemeProps';
export * from './getThemeProps';
