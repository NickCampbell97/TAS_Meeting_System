import { Theme } from './createTheme';

export default function useTheme<T = Theme>(): T;
