import createStyles from '@material-ui/styles/createStyles';

export default createStyles;
