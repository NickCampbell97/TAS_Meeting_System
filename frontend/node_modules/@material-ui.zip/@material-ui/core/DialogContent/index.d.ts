export { default } from './DialogContent';
export * from './DialogContent';
