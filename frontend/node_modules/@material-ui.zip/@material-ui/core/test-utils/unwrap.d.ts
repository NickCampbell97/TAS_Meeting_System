/**
 * @deprecated
 * @param element
 */
export default function unwrap(element: React.ReactElement): React.ReactElement;
