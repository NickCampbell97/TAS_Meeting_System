import SvgIcon from '@material-ui/core/SvgIcon';

export default function createSvgIcon(path: React.ReactNode, displayName: string): typeof SvgIcon;
