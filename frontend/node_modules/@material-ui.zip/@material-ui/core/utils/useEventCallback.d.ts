export interface Cancelable {
  clear(): void;
}

export default function useEventCallback(...args: any[]): void;
