"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = deprecatedPropType;

function deprecatedPropType(validator, reason) {
  if (process.env.NODE_ENV === 'production') {
    return function () {
      return null;
    };
  }

  return function (props, propName, componentName, location, propFullName) {
    var componentNameSafe = componentName || '<<anonymous>>';
    var propFullNameSafe = propFullName || propName;

    if (typeof props[propName] !== 'undefined') {
      return new Error("The ".concat(location, " `").concat(propFullNameSafe, "` of ") + "`".concat(componentNameSafe, "` is deprecated. ").concat(reason));
    }

    return null;
  };
}