export default function ownerDocument(node?: Node): Document;
