"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = setRef;

// TODO v5: consider to make it private
function setRef(ref, value) {
  if (typeof ref === 'function') {
    ref(value);
  } else if (ref) {
    ref.current = value;
  }
}